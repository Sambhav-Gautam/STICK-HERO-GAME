module com.example.skeletonstickhero {
    requires javafx.controls;
    requires javafx.fxml;
    requires junit;
    opens com.example.skeletonstickhero to javafx.fxml;
    exports Game;
    opens Game to javafx.fxml;
}