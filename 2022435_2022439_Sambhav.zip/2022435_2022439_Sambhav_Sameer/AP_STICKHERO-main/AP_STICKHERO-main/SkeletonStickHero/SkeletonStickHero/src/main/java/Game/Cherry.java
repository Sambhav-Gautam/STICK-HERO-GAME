package Game;

import javafx.animation.FadeTransition;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.util.Duration;

public class Cherry {
    private ImageView cherryImageView;
    protected static int cherryScore =0;
    private double xPosition;
    private Label cherryLabel = null;
    private double yPosition;

    public Cherry(double stickTopX, double stickTopY,Pane gamePane) {
        // Load cherry image
        Image cherryImage = new Image("cherry.png"); // Replace "cherry.png" with the actual image file
        cherryImageView = new ImageView(cherryImage);
        // Set cherry size
        cherryImageView.setFitWidth(20);
        cherryImageView.setFitHeight(20);
        // Set initial position (random X, stick bottom Y)
        double randomX = stickTopX + Math.random() * 50; // Adjust the range as needed
        double stickBottomY = stickTopY + 10; // Adjust the value based on the stick thickness
        cherryImageView.setX(randomX);
        cherryImageView.setY(stickBottomY);
        // Set position attributes
        xPosition = randomX;
        yPosition = stickBottomY;
        cherryLabel = new Label("Cherry: 0");
        cherryLabel.setFont(new Font(20));
        cherryLabel.setTextFill(Color.WHITE); // Set text color
        cherryLabel.setStyle("-fx-background-color: #2c3e50; -fx-padding: 5px; -fx-background-radius: 5px;"); // Set background color and padding
        // Position the score label at the middle top of the gamePane
        cherryLabel.setLayoutX(500);
        cherryLabel.setLayoutY(10); // Adjust this value for vertical positioning
        // Apply fade-in animation to the score label
        FadeTransition fadeIn = new FadeTransition(Duration.millis(1500), cherryLabel);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();
        cherryLabel.toFront();
        gamePane.getChildren().add(cherryLabel);
    }
    public void collectCherry(Pane gamePane){
        cherryScore++;
        updateCherryScore(cherryScore);
        gamePane.getChildren().remove(cherryImageView);

    }
    public void addCherry(Pane gamePane){
        if (!gamePane.getChildren().contains(cherryImageView)) {
            gamePane.getChildren().add(cherryImageView);
        }
    }
    public void updateCherryScore(int score) {
        cherryLabel.setText("Cherry: " + score);
    }

    public ImageView getCherryImageView() {
        return cherryImageView;
    }

    public double getXPosition() {
        return xPosition;
    }

    public double getYPosition() {
        return yPosition;
    }

    public void setXPosition(double x) {
        xPosition = x;
        cherryImageView.setX(xPosition);
    }

    public void addToPane(Pane pane) {
        pane.getChildren().add(cherryImageView);
    }

    // You can add more methods if needed, such as removing the cherry from the pane
}
