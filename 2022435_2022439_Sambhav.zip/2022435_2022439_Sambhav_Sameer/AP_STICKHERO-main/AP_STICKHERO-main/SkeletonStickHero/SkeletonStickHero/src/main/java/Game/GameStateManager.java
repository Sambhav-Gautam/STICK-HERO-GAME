package Game;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class GameStateManager {
    private static final String FILE_PATH = "AP_STICKHERO-main/game_state.txt";

    private static Map<String, Integer> gameStates;

    public GameStateManager() throws IOException {
        this.gameStates = loadGameStates();
    }


    public Map<String, Integer> loadGameStates() throws IOException {
        Map<String, Integer> loadedGameStates = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    String username = parts[0];
                    int score = Integer.parseInt(parts[1]);
                    loadedGameStates.put(username, score);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return loadedGameStates;
    }

    private void saveGameStates() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Map.Entry<String, Integer> entry : gameStates.entrySet()) {
                writer.append(entry.getKey() + ":" + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getScore(String username) {
        return gameStates.getOrDefault(username, 0);
    }


    public void updateScore(String username, int newScore) {
        gameStates.put(username, newScore);
        saveGameStates();
    }

    // New method to find the highest score
    public static Map.Entry<String, Integer> findHighestScore() {
        return gameStates.entrySet()
                .stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);
    }
}
