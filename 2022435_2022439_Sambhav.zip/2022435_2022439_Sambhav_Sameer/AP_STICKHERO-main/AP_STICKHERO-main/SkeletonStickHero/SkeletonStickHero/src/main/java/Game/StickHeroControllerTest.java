//import javafx.scene.input.MouseButton;
//import javafx.stage.Stage;
//import org.junit.jupiter.api.Test;
//import org.testfx.api.FxRobot;
//import org.testfx.framework.junit5.ApplicationTest;
//
//import static org.junit.jupiter.api.Assertions.assertTrue;
//
//public class StickHeroControllerTest extends ApplicationTest {
//
//    @Override
//    public void start(Stage stage) {
//        // Start your JavaFX application here (if necessary)
//        // This method is called before each test case
//    }
//
//    @Test
//    public void testStickLengthIncrease() {
//        StickHeroController stickHeroController = new StickHeroController();
//        stickHeroController.stage = "waiting";
//        stickHeroController.isMousePressed = new AtomicBoolean(false);
//        stickHeroController.stickExtensionTimeline = new AtomicReference<>(new Timeline());
//        stickHeroController.Pillar0 = new Rectangle(0, 0, 50, 100);  // You may need to adjust the dimensions
//        stickHeroController.Pillar1 = new Rectangle(100, 0, 50, 100);  // You may need to adjust the dimensions
//
//        // Simulate a mouse press event
//        clickOn("#gamePane").press(MouseButton.PRIMARY);
//
//        // Assertions
//        assertTrue(stickHeroController.isMousePressed.get());
//        assertNotNull(stickHeroController.stick);
//
//        // Assuming stick is created in stickLengthIncrease
//        assertTrue(stickHeroController.stick.getStartX() == stickHeroController.Pillar0.getX() + stickHeroController.Pillar0.getWidth());
//        assertTrue(stickHeroController.stick.getEndX() == stickHeroController.Pillar0.getX() + stickHeroController.Pillar0.getWidth());
//
//        // Assuming you want to check if the stick length is within the range of Pillar0.getX() and Pillar1.getX() + Pillar1.getWidth()
//        assertTrue(stickHeroController.stickLength >= stickHeroController.Pillar0.getX());
//        assertTrue(stickHeroController.stickLength <= stickHeroController.Pillar1.getX() + stickHeroController.Pillar1.getWidth());
//    }
//}
