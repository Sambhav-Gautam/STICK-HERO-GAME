Home_Folder = AP_STICKHERO-main
We have to run StickHeroGame.java in package Game

It is similar to stick hero game present at app store.
We have to hold the mouse button(i.e, on mouse button pressed) for extending the stick.
When the hero is walking on the stick then the hero can be flipped using the mouse click.
We have to collect cherries, and it is reviving feature for the player.
When the total cherries collected is greater than 3 then the player can be revived and 3 cherries will be subtracted from the the account of the player.

Particular data for any user will be saved in text file which is then loaded before playing the game.
The text file will contain the username of the person and the cherries collected by the person.